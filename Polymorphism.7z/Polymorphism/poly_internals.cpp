//#include<iostream>
//using namespace std;
//class base
//{
//public:virtual void foo() { cout << "foo base" << endl; }
//	  virtual void bar() { cout << "bar base" << endl; }
//};
//class derived :public base
//{
//public:virtual void foo() { cout << "foo derived" << endl; }
//	  void mybar() { cout << "my bar derived" << endl; }
//};
//typedef void (*ptr)();
//int main()
//{	
//	base b1;
//	cout << "address of vptr"<< " " << &b1 << endl;
//	cout << "address of vtable" << " " << *(int*)&b1 << endl;
//	ptr p1 = (ptr) * (int*)*(int*)&b1;
//	p1();
//	ptr p2 = (ptr) * (int*)*(int*)&b1+1;
//	p2();
//	derived d1;
//	ptr p3=
//		return 0;
//}