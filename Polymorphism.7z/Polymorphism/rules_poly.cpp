//#include<iostream>
//using namespace std;
//class base
//{
//public:base() { cout << "ctor of base" << endl; }
//	void foo() { cout << "foo base" << endl; }
//	   virtual void bar() {
//		  cout << "bar base" << endl;
//		  //this->foo();
//	  }
//	   virtual void show() = 0; //pure virtual function
//	   virtual ~base() { cout <<"destructor of base"; }
//};
//class derived :public base
//{
//public:derived() { cout << "ctor of derived" << endl; }
//	 void foo() { cout << "foo derived" << endl; }
//	  virtual void bar()
//	  {
//		  cout << "bar of derived" <<endl;
//	}
//};
//int main()
//{
//	derived d1;
//	//base* bptr = &d1;
//	//bptr->bar();
//	return 0;
//}