#include <iostream>
#include "CString.h"
using namespace std;

int main()
{
	{
		CString s1;
		s1.show_string();

		CString s2("sachin");
		s2.show_string();

		CString s3("sehwag");
		s3.show_string();

		CString s4 = s2 + s3;
		s4.show_string();

		/*CString s2('W',10);
		s2.show_string();

		CString ss(s2);
		ss.show_string();*/

	}
	cout << "Leak " << _CrtDumpMemoryLeaks() << endl;
	return 0;
}