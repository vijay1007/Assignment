#include <iostream>
#include <string.h>
#include "CString.h"
using namespace std;
#pragma warning(disable:4996)

CString::CString()
{
	m_len = 0;
	m_pbuff = new char;
	*m_pbuff = '\0';
}

CString::CString(const char* str)
{
	m_len = strlen(str);
	m_pbuff = new char[m_len + 1];

	strcpy(this->m_pbuff, str);

}

CString::CString(const CString& s)
{
	m_len = s.m_len;
	m_pbuff = new char[m_len + 1];
	strcpy(this->m_pbuff, s.m_pbuff);

	cout << "copy conststructor" << endl;
}

CString CString::operator+(const CString& ss)
{
	CString temp;
	delete[] temp.m_pbuff;
	temp.m_len = m_len + ss.m_len;
	temp.m_pbuff = new char[temp.m_len + 1];
	strcpy(temp.m_pbuff, m_pbuff);
	strcat(temp.m_pbuff, ss.m_pbuff);
	return temp;
}

CString& CString::operator+=(const CString& ss)
{
	CString temp;
	delete[] temp.m_pbuff;
	temp.m_len = m_len + ss.m_len;
	temp.m_pbuff = new char[temp.m_len];
	strcpy(temp.m_pbuff, m_pbuff);
	strcat(temp.m_pbuff, ss.m_pbuff);
	return temp;
}

CString::CString(char ch, int no)
{
	m_len = no;
	m_pbuff = new char[m_len + 1];
	memset(m_pbuff, ch, no);
	m_pbuff[m_len] = '\0';
}

void CString::show_string()
{
	cout << m_len << " " << m_pbuff << endl;
}

CString::~CString()
{

	delete[] m_pbuff;
	m_pbuff = nullptr;
}