#pragma once

class CString
{
	char* m_pbuff;
	int m_len;
public:
	CString();//defualt constructor
	CString(const char*);
	CString(char, int);
	CString(const CString& s);
	CString operator+(const CString& ss);

	CString& operator+=(const CString& ss);

	void show_string();
	~CString();//destructor
};