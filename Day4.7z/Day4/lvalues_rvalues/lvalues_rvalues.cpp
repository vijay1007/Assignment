// lvalues_rvalues.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int& add(int &x,int &y)
{
    return x;
}

int& function(int& x)
{
    return x;
}

int&& newfunction(int&& x)
{
    return 99;
}

void foo(int& ref)
{
    cout << "foo & ref" << endl;
}

void foo(int&& ref)
{
    cout<<"foo && ref"<<endl;
}

int main()
{
    int value = 10;
    foo(10);
    foo(value);

    int x = 10;
    int y = 20;
    cout << &x << " " << &y;
    int z = ((x + y) * (x));
    add(x, y) = 99;
    cout << x << endl;

    int&& ref = 10000;
    cout << ref << endl;

    int&& ref1 = 100 + 200;
    cout << ref1 << endl;

    int& ref2 = function(x);
    cout << ref2 << endl;

    int&& ref3 = newfunction(10 + 20);
    cout << ref3 << endl;
    return 0;
}
