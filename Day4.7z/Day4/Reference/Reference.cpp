// Reference.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#define MYMACRO(X,Y) X+Y
using namespace std;

class Demo
{

    int ref;
public:
    Demo(int xx) :ref(xx)
    {
    }

    void operator()(int x,int y)
    {
        cout << "\noperator () is overloaded" << endl;
    }

    void showx()
    {
        cout << ref << endl;

    }

    void myfunction()
    {
        cout << "my member function called" << endl;
    }
};

int add(int x, int y)
{
    return x + y;
}

int sub(int x, int y)
{
    return x - y;
}

int mul(int x, int y)
{
    return x * y;
}

void function(int(*ptr)(int, int))
{
    Demo dd(10);
    cout << ptr(100, 200) << endl;
    cout << add(10, 20) << endl;
    cout << MYMACRO(1000, 200);
    dd(99, 88);
}

int main()
{

    function(add);
    return 0;
}