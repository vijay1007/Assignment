#include <iostream>
#include "payment.h"
using namespace std;

int main()
{
	netpay* net = new netpay();
	net->cal_netpay();
}
