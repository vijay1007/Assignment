#include <iostream>
#include "datetime.h"

int main()
{
    Time t;
    t.accept_time();
    t.convert_time();
    t.get_time();
}
