#include <iostream>
#include "complex.h"

using namespace std;

int main()
{
	Complex c1;
	c1.accept();
	c1.display();
	Complex c2(10, -3);
	c2.display();
	return 0;
}