// references.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{
	int x = 10;
	int& ref = x;           //ref must be intialized at the place of declaration and ref is a const pointer
	cout << ref << endl;
	//ref = 2000;
	ref++;
	cout << x <<" " << ref << endl;
	cout << &x << " " << &ref << endl;
	int* ptr = &ref;	//you cannot create pointer to reference but one can create reference to pointer
	cout << *ptr << endl;
	*ptr = 99;
	int*& ref1 = ptr;
	cout << *ref1 << endl;

	int const& constref = 10;
	cout << constref << endl;

	int arr[5];
	int (*brr)[5];

	return 0;
}