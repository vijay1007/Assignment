#pragma once

void function();
#define PI 3.142
extern int value;

static int myvalue = 99;

static void foo1();