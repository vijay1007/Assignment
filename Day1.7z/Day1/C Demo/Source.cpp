#include<stdio.h>
#include "header.h"
#include<iostream>

extern void function()
{
	value = 2000;
	myvalue = 9999;
	printf("function called %d %d\n",value,myvalue);

}
