#pragma once

int add(int, int);
void bar();