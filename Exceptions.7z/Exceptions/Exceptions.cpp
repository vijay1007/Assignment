// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include<fstream>
using namespace std;
void function(ofstream &out)
{
	out << __DATE__ << " " << __TIME__ << " " << __FILE__ << " " << __FUNCTION__ << " " << __LINE__<< "this is a critical error" << endl;
}
class Employee
{
	string empname;
	int empid;
public:Employee(){}
	Employee(string name, int id) :empname(name), empid(id){}
	void accept() {
		cout << "enter id name" << endl;
		cin >> empid >> empname;
	}
	  void show() { cout << "enter info is" << empid << " " << empname << empname << endl; }

};

int main()
{
	//ofstream out("mylog.txt", ios::out);
	//ofstream out;
	//ifstream iff;
	//iff.open("records.txt", ios::out);
	//string player, country;
	//int runs;
	//if (iff.is_open())  //out
	//{
	//	while (!iff.eof())
	//	{
	//		iff >> player >> runs >> country;
	//		if (iff.eof())
	//		{
	//			break;
	//		}
	//		else
	//		cout << player << " " << runs << " " << endl;
	//	}
	//	/*out << "sachin " << 100 << "india" << endl;
	//	out << "ricky " << 200 << "india" << endl;
	//	out << "kallis " << 300 << "india" << endl;*/

	//}
	//else
	//{
	//	cout << "unable to create file" << endl;
	//}
	//out.close();
	/*out << __DATE__ << " " <<__TIME__<<" "<< __FILE__ <<" " <<__FUNCTION__<<" "<<__LINE__<<"this is a critical error"<<endl;
	function(out);*/

	//ofstream out;
	//out.open("employees.txt", ios::app|ios::binary);
	//if (out.is_open())  //out
	//{
	//	Employee e1[3];
	//	for (int i = 0; i < 3; ++i)
	//	{
	//		e1[i].accept();
	//		out.write((char*)&e1[i], sizeof(e1[i]));

	//}
	//	/*out << "sachin " << 100 << "india" << endl;
	//	out << "ricky " << 200 << "india" << endl;
	//	out << "kallis " << 300 << "india" << endl;*/

	//}
	//else
	//{
	//	cout << "unable to create file" << endl;
	//}
	//ofstream out;
	//out.open("employees.txt", ios::app|ios::binary);
	//if (out.is_open())  //out
	//{
	//	Employee e1[3];
	//	for (int i = 0; i < 3; ++i)
	//	{
	//		e1[i].accept();
	//		out.write((char*)&e1[i], sizeof(e1[i]));

	//}
	//	/*out << "sachin " << 100 << "india" << endl;
	//	out << "ricky " << 200 << "india" << endl;
	//	out << "kallis " << 300 << "india" << endl;*/

	//}
	//else
	//{
	//	cout << "unable to create file" << endl;
	//}

	//ofstream out;
	//out.open("employees.txt", ios::app|ios::binary);
	//if (out.is_open())  //out
	//{
	//	Employee e1[3];
	//	for (int i = 0; i < 3; ++i)
	//	{
	//		e1[i].accept();
	//		out.write((char*)&e1[i], sizeof(e1[i]));

	//}
	//	/*out << "sachin " << 100 << "india" << endl;
	//	out << "ricky " << 200 << "india" << endl;
	//	out << "kallis " << 300 << "india" << endl;*/

	//}
	//else
	//{
	//	cout << "unable to create file" << endl;
	//}
	//ofstream out;
	//ifstream iff;
	//iff.open("numbers.txt", ios::in);
	//{
	//	float brr[10] = { 0 };
	//	if (iff.is_open())
	//		iff.read((char*)&brr, sizeof(brr));
	//	else
	//	{
	//		cout << "unable to create file" << endl;
	//	}
	//	out.close();
	//	cout << "elements are" << endl;
	//	for (int i = 0; i < 10; ++i)
	//		cout << brr[i] << endl;

ofstream out;
out.open("numbers.txt", ios::out);
if (out.is_open())
{
	float arr[10] = { 1.2f,3.4f,5.6f,7.3f,8.6f,9.1f,12.3f,11.2f,90.2f,2.3f };
	out.write((char*)&arr, sizeof(arr));
}
else
{
	cout << "Unable to create file" << endl;
}
out.close();



ifstream in;
in.open("numbers.txt", ios::in);
float brr[10] = { 0 };
if (in.is_open())
{
	for (int i = 0; i < 3; ++i)
	{

		in.read((char*)&brr, sizeof(brr));
	}
}
else
{
	cout << "Unable to read file" << endl;
}
in.close();
cout << "elemts are" << endl;
for (int i = 0; i < 10; ++i)
{
	cout << brr[i] << endl;
}
return 0;
	}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
//s Debug program: F5 or Debug > Start Debugging menu
// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
