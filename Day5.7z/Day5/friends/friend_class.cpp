#include<iostream>
using namespace std;

class XYZ
{
	int x;
public: XYZ() :x(20) {}
	  void showx()
	  {
		  cout << x << endl;
	  }
	  void foo();
	  void bar();
};

class ABC
{
	int a;
public: ABC() :a(10) {}
	  void showa() 
	  { 
		  cout << a << endl; 
	  }
	  friend class XYZ;
};

void XYZ::foo()
{
	ABC aa;
	aa.a = 99;
	cout << aa.a << endl;
}

void XYZ::bar()
{
	ABC aa;
	aa.a = 88;
	cout << aa.a << endl;
}

int main()
{
	ABC a1;
	a1.showa();
	XYZ x1;
	x1.showx();
}