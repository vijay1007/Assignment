#include<iostream>
#include "a.h"
using namespace std;

ABC::ABC():a(10)
{

}
ABC::ABC(int aa) : a(aa)
{

}
ABC::ABC(const XYZ& x)
{
	cout << "construtor syntax called" << endl;
	a.getx();
}