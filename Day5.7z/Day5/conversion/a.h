#pragma once


class ABC
{
	int a;
public: ABC();
	    ABC(int);
		void operator=(const);
	    void showa();
};