//// conversion.cpp : This file contains the 'main' function. Program execution begins and ends there.
////
//
//#include <iostream>
//using namespace std;
//
//void foo(int* ptr)
//{
//	cout << "foo called" << endl;
//}
//
//class Demo
//{
//	int x;
//	float y;
//	char z;
//public:Demo():x(10),y(3.14),z('A') {}
//	  void show() { cout << x <<" " << y <<" " << z << endl; }
//};
//
//int main()
//{
//	const int x = 100;
//	foo(const_cast<int*>(&x));
//	foo((int*)&x);
//	cout << static_cast<float>(1) / 2 << endl;
//	cout << (float)1 / 2 << endl;
//	int* ptr=nullptr;
//	double* dptr=nullptr;
//	dptr = (double*)ptr;         //c style casting
//	dptr = reinterpret_cast<double*>(ptr); //c++ casting
//
//	Demo d1;
//	d1.show();
//	ptr = reinterpret_cast<int*>(& d1);
//	*ptr = 99;
//	ptr++;
//	(*reinterpret_cast<float*>(ptr)) = 99.99f;
//	ptr++;
//	(*reinterpret_cast<char*>(ptr)) = 'S';
//	d1.show();
//	ptr++;
//	return 0;
//}
