//#include <iostream>
//using namespace std;
//
//class Fraction
//{
//	int num, den;
//public:Fraction() :num(0), den(0) {}
//	   explicit Fraction(int n) 
//	   { 
//		   num = n; den = 0;
//		   cout<<"constructor syntax"<<endl;
//	   }
//
//	   Fraction(int num, int den) :num(num), den(den) {}
//
//	   void operator=(int val)
//	   {
//		   this->num = val;
//		   cout << "assignment operator" << endl;
//	   }
//
//	   void showresult() 
//	   { 
//		   cout << num << " " << den << endl; 
//	   }
//
//	   operator float()
//	   {
//		   return static_cast<float>(num) / den;
//	   }
//};
//
//int main()
//{
//	Fraction f1(10, 3),f2(11,4);
//	f1 = Fraction(25);
//	f1.showresult();
//	f2 = 25;
//	f2.showresult();
//
//	float result = f2.operator float();
//	cout << result << endl;
//	result = f2.operator float();
//	cout << result << endl;
//
//	return 0;
//}