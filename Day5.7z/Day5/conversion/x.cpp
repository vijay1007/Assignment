#include <iostream>
#include"x.h"
using namespace std;

XYZ::XYZ() : x(99)
{

}

XYZ::XYZ(int xx) : x(99)
{

}

int XYZ::getx()const
{
	return x;
}

void XYZ::showx()
{
	cout << x << endl;
}

XYZ::operator ABC()
{
	cout << "operator conversion" << endl;
	return ABC(x);
}