#include<iostream>
#include "a.h"
#include "x.h"

int main()
{
	ABC a1(1000);
	XYZ x1(2000);

	a1 = x1;
	a1.showa();

	a1 = ABC(x1);
	a1.showa();

	a1 = x1.operator ABC();
	a1.showa();
	return 0;
}