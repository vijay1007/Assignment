#pragma once


class XYZ
{
	int a;
public: XYZ();
	    XYZ(int);
		int getx() const;
		operator ABC();
	    void showx();
};